The following sources are a fork from Box2D, changed to fit Chowdren better:

growablestack.h
aabbtree.h
aabbtree.cpp
settings.h
collision.h

Function and class names have been changed so as to not collide with the
older Box2D version used by the Phizix object.
